import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_app/settings")({
  head: () => ({ meta: [{ title: "Settings — Vireo" }, { name: "description", content: "Your profile and content preferences." }] }),
  component: SettingsPage,
});

const LANGS = ["English", "Hindi", "Spanish", "French", "German", "Portuguese", "Arabic", "Japanese"];
const TONES = ["Friendly", "Professional", "Witty", "Bold", "Inspirational", "Educational"];

function SettingsPage() {
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [c, setC] = useState({ niche: "", audience: "", language: "English", tone: "Friendly" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("name").eq("id", user.id).maybeSingle().then(({ data }) => setName(data?.name ?? ""));
    supabase.from("creator_profiles").select("*").eq("user_id", user.id).maybeSingle().then(({ data }) => {
      if (data) setC({ niche: data.niche, audience: data.audience, language: data.language, tone: data.tone });
    });
  }, [user]);

  async function save() {
    if (!user) return;
    setSaving(true);
    const a = await supabase.from("profiles").upsert({ id: user.id, email: user.email ?? null, name });
    const b = await supabase.from("creator_profiles").upsert({ user_id: user.id, ...c }, { onConflict: "user_id" });
    setSaving(false);
    if (a.error || b.error) toast.error("Couldn't save settings.");
    else toast.success("Settings saved");
  }

  async function resetPassword() {
    if (!user?.email) return;
    const { error } = await supabase.auth.resetPasswordForEmail(user.email, { redirectTo: window.location.origin + "/reset-password" });
    if (error) toast.error(error.message);
    else toast.success("Password reset email sent.");
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6 pt-4">
      <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>

      <section className="card-soft space-y-4 p-5 md:p-7">
        <h2 className="text-lg font-semibold">Profile</h2>
        <div className="space-y-1.5"><Label>Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="space-y-1.5"><Label>Email</Label><Input value={user?.email ?? ""} disabled /></div>
      </section>

      <section className="card-soft space-y-4 p-5 md:p-7">
        <h2 className="text-lg font-semibold">Content preferences</h2>
        <div className="space-y-1.5"><Label>Niche</Label><Input placeholder="e.g. Fitness, Tech reviews, Cooking" value={c.niche} onChange={(e) => setC({ ...c, niche: e.target.value })} /></div>
        <div className="space-y-1.5"><Label>Audience</Label><Input placeholder="e.g. Busy professionals in their 30s" value={c.audience} onChange={(e) => setC({ ...c, audience: e.target.value })} /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5"><Label>Language</Label>
            <Select value={c.language} onValueChange={(v) => setC({ ...c, language: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{LANGS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent></Select>
          </div>
          <div className="space-y-1.5"><Label>Content tone</Label>
            <Select value={c.tone} onValueChange={(v) => setC({ ...c, tone: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TONES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
          </div>
        </div>
      </section>

      <Button variant="sage" size="lg" className="w-full" onClick={save} disabled={saving}>{saving ? "Saving…" : "Save settings"}</Button>

      <section className="card-soft space-y-3 p-5 md:p-7">
        <h2 className="text-lg font-semibold">Account</h2>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={resetPassword}>Reset password</Button>
          <Button variant="outline" onClick={() => supabase.auth.signOut()}>Sign out</Button>
        </div>
      </section>
    </div>
  );
}
