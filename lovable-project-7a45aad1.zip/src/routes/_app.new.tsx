import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Upload, Link2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_app/new")({
  head: () => ({ meta: [{ title: "New project — Vireo" }, { name: "description", content: "Upload a video to generate content." }] }),
  component: NewProject,
});

const MAX_MB = 500;

function uploadWithProgress(url: string, file: File, onProgress: (p: number) => void) {
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url);
    xhr.setRequestHeader("x-upsert", "false");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => (xhr.status < 300 ? resolve() : reject(new Error("Upload failed")));
    xhr.onerror = () => reject(new Error("Upload failed — check your connection."));
    const form = new FormData();
    form.append("cacheControl", "3600");
    form.append("", file);
    xhr.send(form);
  });
}

function NewProject() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"upload" | "url">("upload");
  const [file, setFile] = useState<File | null>(null);
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [progress, setProgress] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function pick(f: File | undefined) {
    if (!f) return;
    if (!f.type.startsWith("video/")) { toast.error("Please choose a video file."); return; }
    if (f.size > MAX_MB * 1024 * 1024) { toast.error(`Video must be under ${MAX_MB}MB.`); return; }
    setFile(f);
    if (!title) setTitle(f.name.replace(/\.[^.]+$/, ""));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (mode === "upload" && !file) { toast.error("Choose a video to upload."); return; }
    if (mode === "url" && !/^https?:\/\//.test(url)) { toast.error("Enter a valid video URL."); return; }
    if (!title.trim()) { toast.error("Give your project a title."); return; }

    const { data: project, error } = await supabase
      .from("projects")
      .insert({ user_id: user.id, title: title.trim(), notes, status: mode === "url" ? "queued" : "uploading", video_url: mode === "url" ? url : null })
      .select()
      .single();
    if (error || !project) { toast.error("Couldn't create project. Please try again."); return; }

    if (mode === "upload" && file) {
      try {
        setProgress(0);
        const path = `${user.id}/${project.id}-${file.name.replace(/[^\w.-]/g, "_")}`;
        const { data: signed, error: se } = await supabase.storage.from("videos").createSignedUploadUrl(path);
        if (se || !signed) throw new Error("Upload failed");
        await uploadWithProgress(signed.signedUrl, file, setProgress);
        await supabase.from("projects").update({ video_url: path, status: "queued" }).eq("id", project.id);
      } catch (err) {
        await supabase.from("projects").update({ status: "failed", error: "Upload failed." }).eq("id", project.id);
        setProgress(null);
        { toast.error((err as Error).message); return; }
      }
    }
    navigate({ to: "/projects/$id", params: { id: project.id } });
  }

  const uploading = progress !== null;

  return (
    <form onSubmit={submit} className="mx-auto max-w-2xl space-y-6 pt-4">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">New project</h1>
        <p className="mt-1 text-muted-foreground">Upload a video or paste a link.</p>
      </div>

      <div className="card-soft space-y-5 p-5 md:p-7">
        <div className="grid grid-cols-2 gap-1 rounded-full bg-cream p-1">
          {(["upload", "url"] as const).map((m) => (
            <button type="button" key={m} onClick={() => setMode(m)} className={`flex items-center justify-center gap-2 rounded-full py-2.5 text-sm font-medium ${mode === m ? "bg-card shadow-soft" : "text-muted-foreground"}`}>
              {m === "upload" ? <><Upload className="size-4" />Upload video</> : <><Link2 className="size-4" />Paste URL</>}
            </button>
          ))}
        </div>

        {mode === "upload" ? (
          <button type="button" onClick={() => inputRef.current?.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); pick(e.dataTransfer.files[0]); }}
            className="flex w-full flex-col items-center justify-center rounded-2xl border-2 border-dashed border-input bg-cream/60 px-4 py-10 text-center">
            <span className="text-3xl">🎬</span>
            <span className="mt-2 font-medium">{file ? file.name : "Drop a video or tap to choose"}</span>
            <span className="text-xs text-muted-foreground">{file ? `${(file.size / 1024 / 1024).toFixed(1)} MB` : `MP4, MOV, WEBM · up to ${MAX_MB}MB`}</span>
            <input ref={inputRef} type="file" accept="video/*" hidden onChange={(e) => pick(e.target.files?.[0])} />
          </button>
        ) : (
          <div className="space-y-1.5"><Label htmlFor="url">Video URL</Label><Input id="url" placeholder="https://youtube.com/watch?v=…" value={url} onChange={(e) => setUrl(e.target.value)} /></div>
        )}

        <div className="space-y-1.5"><Label htmlFor="title">Project title</Label><Input id="title" placeholder="e.g. My 5-minute morning routine" value={title} onChange={(e) => setTitle(e.target.value)} /></div>
        <div className="space-y-1.5">
          <Label htmlFor="notes">Transcript or what the video is about</Label>
          <Textarea id="notes" rows={5} placeholder="Paste the transcript or describe the key points. The more detail, the better the content." value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>

        {uploading && (
          <div>
            <div className="mb-1 flex justify-between text-xs text-muted-foreground"><span>Uploading…</span><span>{progress}%</span></div>
            <div className="h-2 rounded-full bg-secondary"><div className="h-full rounded-full bg-sage transition-all" style={{ width: `${progress}%` }} /></div>
          </div>
        )}

        <Button type="submit" variant="clay" size="lg" className="w-full" disabled={uploading}>{uploading ? "Uploading…" : "Generate content"}</Button>
      </div>
    </form>
  );
}
