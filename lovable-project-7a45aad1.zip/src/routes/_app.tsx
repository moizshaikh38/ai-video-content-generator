import { createFileRoute, Link, Outlet, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { LayoutGrid, Plus, History, Settings, LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/_app")({
  ssr: false,
  component: AppLayout,
});

const links = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutGrid },
  { to: "/new", label: "New", icon: Plus },
  { to: "/history", label: "History", icon: History },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

function AppLayout() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  if (loading || !user)
    return <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">Loading…</div>;

  return (
    <div className="min-h-screen pb-24 md:pb-10">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Logo to="/dashboard" />
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className="rounded-full px-4 py-2 text-sm text-muted-foreground hover:bg-secondary" activeProps={{ className: "bg-card text-foreground shadow-soft" }}>
              {l.label}
            </Link>
          ))}
        </nav>
        <button onClick={() => supabase.auth.signOut()} className="flex items-center gap-2 rounded-full px-3 py-2 text-sm text-muted-foreground hover:bg-secondary" aria-label="Sign out">
          <LogOut className="size-4" /><span className="hidden sm:inline">Sign out</span>
        </button>
      </header>
      <main className="mx-auto max-w-6xl px-4 sm:px-6">
        <Outlet />
      </main>
      <nav className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-4 rounded-3xl bg-card p-1.5 shadow-lift outline outline-1 outline-border md:hidden">
        {links.map((l) => (
          <Link key={l.to} to={l.to} className="flex flex-col items-center gap-1 rounded-2xl py-2 text-[11px] text-muted-foreground" activeProps={{ className: "bg-cream text-foreground" }}>
            <l.icon className="size-5" />{l.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
