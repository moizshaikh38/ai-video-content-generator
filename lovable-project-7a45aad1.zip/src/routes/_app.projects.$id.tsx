import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Check, Copy, Pencil, RefreshCw, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { generateKit, regenerateOutput } from "@/lib/content.functions";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge, isProcessing } from "@/components/StatusBadge";

export const Route = createFileRoute("/_app/projects/$id")({
  head: () => ({ meta: [{ title: "Project — Vireo" }, { name: "description", content: "Your generated content kit." }] }),
  component: ProjectPage,
});

const STAGES = [
  ["uploading", "Uploading"],
  ["transcribing", "Transcribing"],
  ["analyzing", "Analyzing"],
  ["generating", "Generating content"],
  ["complete", "Complete"],
] as const;

const TABS = [
  { key: "youtube", label: "YouTube", groups: [["title", "Title ideas"], ["description", "Description"], ["chapters", "Chapters"]] },
  { key: "instagram", label: "Instagram", groups: [["hook", "Reel hooks"], ["caption", "Caption"], ["hashtags", "Hashtags"]] },
  { key: "shorts", label: "Shorts / Reels", groups: [["moment", "Best moments"]] },
  { key: "social", label: "Social", groups: [["linkedin", "LinkedIn post"], ["x", "X post"]] },
] as const;

function ProjectPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const runKit = useServerFn(generateKit);
  const started = useRef(false);

  const { data: project, isLoading } = useQuery({
    queryKey: ["project", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
    refetchInterval: (q) => (q.state.data && isProcessing(q.state.data.status) ? 1500 : false),
  });

  const { data: outputs = [] } = useQuery({
    queryKey: ["outputs", id],
    enabled: project?.status === "complete",
    queryFn: async () => {
      const { data, error } = await supabase.from("content_outputs").select("*").eq("project_id", id).order("position");
      if (error) throw error;
      return data;
    },
  });

  async function start() {
    const res = await runKit({ data: { projectId: id } });
    if (!res.ok && "error" in res) toast.error(res.error);
    qc.invalidateQueries({ queryKey: ["project", id] });
    qc.invalidateQueries({ queryKey: ["projects"] });
  }

  useEffect(() => {
    if (project?.status === "queued" && !started.current) {
      started.current = true;
      start();
    }
  }, [project?.status]);

  if (isLoading) return <p className="py-20 text-center text-muted-foreground">Loading…</p>;
  if (!project) return <p className="py-20 text-center text-muted-foreground">Project not found.</p>;

  return (
    <div className="space-y-6 pt-4">
      <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" />Back</Link>
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">{project.title}</h1>
        <StatusBadge status={project.status} />
      </div>

      {project.status === "failed" ? (
        <div className="card-soft p-7 text-center">
          <p className="font-medium">Something went wrong</p>
          <p className="mt-1 text-sm text-muted-foreground">{project.error ?? "Please try again."}</p>
          {project.video_url && <Button variant="clay" className="mt-5" onClick={() => { started.current = true; start(); }}>Try again</Button>}
        </div>
      ) : project.status !== "complete" ? (
        <Processing status={project.status} />
      ) : (
        <Workspace outputs={outputs} projectId={id} />
      )}
    </div>
  );
}

function Processing({ status }: { status: string }) {
  const idx = Math.max(0, STAGES.findIndex(([s]) => s === (status === "queued" ? "transcribing" : status)));
  return (
    <div className="card-soft mx-auto max-w-md p-7">
      <p className="mb-6 text-center text-sm text-muted-foreground">Hang tight — this usually takes under a minute.</p>
      <ol className="space-y-1">
        {STAGES.map(([key, label], i) => {
          const done = i < idx;
          const active = i === idx;
          return (
            <li key={key}>
              <div className="flex items-center gap-3 py-2">
                <span className={`grid size-8 place-items-center rounded-full text-xs font-semibold ${done ? "bg-sage text-sage-foreground" : active ? "bg-clay text-clay-foreground animate-pulse" : "bg-secondary text-muted-foreground"}`}>
                  {done ? <Check className="size-4" /> : i + 1}
                </span>
                <span className={active ? "font-medium" : done ? "" : "text-muted-foreground"}>{label}</span>
              </div>
              {i < STAGES.length - 1 && <div className={`ml-4 h-3 w-px ${done ? "bg-sage" : "bg-border"}`} />}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

type Output = { id: string; platform: string; content_type: string; content: string };

function Workspace({ outputs, projectId }: { outputs: Output[]; projectId: string }) {
  const [tab, setTab] = useState<string>("youtube");
  const current = TABS.find((t) => t.key === tab)!;
  return (
    <div>
      <div className="scrollbar-none -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-medium transition ${tab === t.key ? "bg-ink text-cream shadow-ink" : "bg-card text-muted-foreground outline outline-1 outline-border"}`}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="mt-5 space-y-6">
        {current.groups.map(([type, label]) => {
          const items = outputs.filter((o) => o.platform === current.key && o.content_type === type);
          return (
            <section key={type}>
              <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.15em] text-clay">{label}</h2>
              <div className="grid gap-3 md:grid-cols-2">
                {items.map((o) => <OutputCard key={o.id} output={o} projectId={projectId} />)}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function OutputCard({ output, projectId }: { output: Output; projectId: string }) {
  const qc = useQueryClient();
  const regen = useServerFn(regenerateOutput);
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(output.content);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  useEffect(() => setText(output.content), [output.content]);

  async function save() {
    const { error } = await supabase.from("content_outputs").update({ content: text }).eq("id", output.id);
    if (error) { toast.error("Couldn't save."); return; }
    setEditing(false);
    qc.invalidateQueries({ queryKey: ["outputs", projectId] });
    toast.success("Saved");
  }
  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }
  async function regenerate() {
    setBusy(true);
    const res = await regen({ data: { outputId: output.id } });
    setBusy(false);
    if (!res.ok) { toast.error(res.error); return; }
    setText(res.content);
    qc.invalidateQueries({ queryKey: ["outputs", projectId] });
  }

  return (
    <div className={`rounded-2xl bg-card p-4 shadow-soft outline outline-1 outline-border ${busy ? "opacity-60" : ""}`}>
      {editing ? (
        <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={Math.min(14, Math.max(3, text.split("\n").length + 1))} className="bg-cream" />
      ) : (
        <p className="whitespace-pre-wrap text-sm leading-relaxed">{busy ? "Regenerating…" : text}</p>
      )}
      <div className="mt-3 flex flex-wrap justify-end gap-1">
        {editing ? (
          <>
            <Button size="sm" variant="ghost" onClick={() => { setText(output.content); setEditing(false); }}>Cancel</Button>
            <Button size="sm" variant="sage" onClick={save}>Save</Button>
          </>
        ) : (
          <>
            <Button size="sm" variant="ghost" onClick={() => setEditing(true)} disabled={busy}><Pencil />Edit</Button>
            <Button size="sm" variant="ghost" onClick={regenerate} disabled={busy}><RefreshCw className={busy ? "animate-spin" : ""} />Regenerate</Button>
            <Button size="sm" variant="ghost" onClick={copy}>{copied ? <Check /> : <Copy />}{copied ? "Copied" : "Copy"}</Button>
          </>
        )}
      </div>
    </div>
  );
}
