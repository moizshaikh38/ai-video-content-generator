import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StatusBadge, isProcessing } from "@/components/StatusBadge";
import { projectsQuery } from "@/lib/projects";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Vireo" }, { name: "description", content: "Your Vireo projects." }] }),
  component: Dashboard,
});

const MONTHLY_LIMIT = 3;

function Dashboard() {
  const { data: projects = [], isLoading } = useQuery({
    ...projectsQuery,
    refetchInterval: (q) => (q.state.data?.some((p) => isProcessing(p.status)) ? 2000 : false),
  });
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const used = projects.filter((p) => new Date(p.created_at) >= monthStart).length;
  const processing = projects.filter((p) => isProcessing(p.status)).length;

  return (
    <div className="space-y-8 pt-4">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">Your studio</h1>
          <p className="mt-1 text-muted-foreground">One video in. Content everywhere out.</p>
        </div>
        <Button variant="clay" size="lg" asChild><Link to="/new"><Plus />Create new project</Link></Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Videos this month" value={`${used} / ${MONTHLY_LIMIT}`} sub="Free plan" bar={Math.min(100, (used / MONTHLY_LIMIT) * 100)} />
        <Stat label="Processing now" value={String(processing)} sub={processing ? "Working on it…" : "All caught up"} />
        <Stat label="Total projects" value={String(projects.length)} sub="All time" />
      </div>

      <section className="card-soft p-5 md:p-7">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Recent projects</h2>
          <Link to="/history" className="text-sm text-muted-foreground hover:text-foreground">View all</Link>
        </div>
        {isLoading ? (
          <p className="py-8 text-center text-sm text-muted-foreground">Loading…</p>
        ) : projects.length === 0 ? (
          <div className="rounded-2xl bg-cream py-12 text-center">
            <p className="text-3xl">🎬</p>
            <p className="mt-2 font-medium">No projects yet</p>
            <p className="text-sm text-muted-foreground">Upload your first video to get a content kit.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {projects.slice(0, 5).map((p) => (
              <li key={p.id}>
                <Link to="/projects/$id" params={{ id: p.id }} className="flex items-center justify-between gap-3 py-3.5">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{p.title}</p>
                    <p className="text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</p>
                  </div>
                  <StatusBadge status={p.status} />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value, sub, bar }: { label: string; value: string; sub: string; bar?: number }) {
  return (
    <div className="card-soft p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.15em] text-clay">{label}</p>
      <p className="mt-2 font-display text-3xl font-semibold">{value}</p>
      {bar !== undefined && <div className="mt-3 h-1.5 rounded-full bg-secondary"><div className="h-full rounded-full bg-sage" style={{ width: `${bar}%` }} /></div>}
      <p className="mt-2 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}
