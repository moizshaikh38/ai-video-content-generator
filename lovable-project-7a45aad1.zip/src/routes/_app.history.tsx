import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { projectsQuery, deleteProject } from "@/lib/projects";

export const Route = createFileRoute("/_app/history")({
  head: () => ({ meta: [{ title: "Project history — Vireo" }, { name: "description", content: "All your Vireo projects." }] }),
  component: HistoryPage,
});

function HistoryPage() {
  const qc = useQueryClient();
  const { data: projects = [], isLoading } = useQuery(projectsQuery);

  async function remove(id: string, url: string | null) {
    try {
      await deleteProject(id, url);
      qc.invalidateQueries({ queryKey: ["projects"] });
      toast.success("Project deleted");
    } catch {
      toast.error("Couldn't delete project.");
    }
  }

  return (
    <div className="space-y-6 pt-4">
      <h1 className="text-3xl font-semibold tracking-tight">Project history</h1>
      <div className="card-soft p-2 md:p-4">
        {isLoading ? <p className="py-10 text-center text-sm text-muted-foreground">Loading…</p> :
          projects.length === 0 ? <p className="py-10 text-center text-sm text-muted-foreground">No projects yet.</p> : (
            <ul className="divide-y divide-border">
              {projects.map((p) => (
                <li key={p.id} className="flex items-center gap-3 px-3 py-3.5">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{p.title}</p>
                    <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                      {new Date(p.created_at).toLocaleDateString()} <StatusBadge status={p.status} />
                    </div>
                  </div>
                  <Button size="sm" variant="outline" asChild><Link to="/projects/$id" params={{ id: p.id }}>Open</Link></Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild><Button size="icon" variant="ghost" aria-label="Delete project"><Trash2 /></Button></AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete this project?</AlertDialogTitle>
                        <AlertDialogDescription>The video and all generated content will be removed.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => remove(p.id, p.video_url)}>Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </li>
              ))}
            </ul>
          )}
      </div>
    </div>
  );
}
