import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/lib/auth";
import { Check } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Vireo — Turn One Video Into Content Everywhere" },
      { name: "description", content: "Upload a video and let AI create titles, captions, hooks and social content from it." },
      { property: "og:title", content: "Vireo — Turn One Video Into Content Everywhere" },
      { property: "og:description", content: "Upload a video and let AI create titles, captions, hooks and social content from it." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const steps = [
  ["Upload", "Drop a clip or paste a link."],
  ["AI analysis", "Finds the topic, key points and best moments."],
  ["Generate", "Drafts content for every platform."],
  ["Edit", "Tweak anything inline."],
  ["Copy", "One tap, ready to post."],
];

const plans = [
  { name: "Free", price: "$0", desc: "3 videos a month", perks: ["All platforms", "Edit & copy"] },
  { name: "Creator", price: "$19", desc: "30 videos a month", perks: ["Everything in Free", "Regenerate anytime", "Custom tone & niche"], featured: true },
  { name: "Studio", price: "$49", desc: "Unlimited videos", perks: ["Everything in Creator", "Priority processing"] },
];

function Landing() {
  const { user } = useAuth();
  const cta = user ? "/dashboard" : "/auth";
  return (
    <div className="min-h-screen">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Logo />
        <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#how">How it works</a>
          <a href="#features">Formats</a>
          <a href="#pricing">Pricing</a>
        </div>
        <div className="flex items-center gap-3">
          {!user && <Link to="/auth" className="hidden text-sm text-muted-foreground sm:block">Sign in</Link>}
          <Button variant="sage" asChild><Link to={cta}>{user ? "Dashboard" : "Get Started"}</Link></Button>
        </div>
      </nav>

      <header className="mx-auto max-w-6xl px-6 pb-10 pt-12 text-center md:pt-16">
        <span className="inline-block rounded-full bg-sage/10 px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.2em] text-sage">One upload, every platform</span>
        <h1 className="mx-auto mt-6 max-w-4xl text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl md:text-7xl">Turn One Video Into Content Everywhere</h1>
        <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">Upload a video and let AI create titles, captions, hooks and social content from it.</p>
      </header>

      <section className="mx-auto max-w-3xl px-6">
        <div className="flex flex-col items-stretch gap-2 rounded-[2rem] bg-card p-3 shadow-lift outline outline-1 outline-border sm:flex-row">
          <div className="flex flex-1 items-center gap-3 rounded-2xl bg-cream/70 px-4 py-3 text-muted-foreground">
            <span className="text-2xl">🎬</span>
            <span className="truncate">Paste a video URL or upload a clip…</span>
          </div>
          <Button variant="clay" size="lg" asChild><Link to={cta}>Get Started</Link></Button>
        </div>
        <p className="mt-4 text-center text-xs text-muted-foreground">MP4, MOV, YouTube or Instagram links · No credit card required</p>
      </section>

      <section className="mx-auto mt-16 max-w-6xl px-6">
        <div className="rounded-[2.5rem] bg-card p-6 shadow-soft outline outline-1 outline-border md:p-8">
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="size-2.5 animate-pulse rounded-full bg-sage" />
              <span className="font-display text-lg font-semibold">Your content kit</span>
            </div>
            <span className="text-xs uppercase tracking-widest text-muted-foreground">Example</span>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Sample label="YouTube titles" meta="5 options">
              <div className="space-y-2.5 font-medium">
                <p>I Rebuilt My Morning in 5 Minutes</p>
                <p>The 5-Minute Routine That Fixed My Focus</p>
                <p>Why 5 Minutes Beats an Hour Every Time</p>
              </div>
            </Sample>
            <Sample label="Instagram caption" meta="Ready">
              Five minutes. That's the whole routine. 🌿 No apps, no alarm battles — just one small shift before the day gets loud. #morningroutine #focus
            </Sample>
            <Sample label="Shorts moments" meta="3 clips">
              <div className="flex gap-3">
                {["0:00–0:18", "1:12–1:30", "3:05–3:22"].map((t) => (
                  <div key={t} className="flex-1 rounded-xl bg-card p-2 outline outline-1 outline-border">
                    <div className="grid aspect-[9/16] place-items-center rounded-lg bg-cream"><span className="text-[9px] uppercase tracking-widest text-muted-foreground">{t}</span></div>
                  </div>
                ))}
              </div>
            </Sample>
            <Sample label="LinkedIn post" meta="Ready">
              I used to think productivity meant more hours. Turns out it meant five better ones. Here's the tiny morning structure that changed how I work.
            </Sample>
          </div>
        </div>
      </section>

      <section id="how" className="mx-auto mt-24 max-w-6xl px-6">
        <h2 className="text-center text-3xl font-semibold tracking-tight md:text-4xl">How it works</h2>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 md:grid-cols-5">
          {steps.map(([t, d], i) => (
            <div key={t} className="card-soft p-5">
              <span className="text-xs font-semibold uppercase tracking-[0.15em] text-clay">0{i + 1}</span>
              <h3 className="mt-2 text-lg font-semibold">{t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="mx-auto mt-24 grid max-w-6xl gap-6 px-6 md:grid-cols-3">
        <Feature icon="⚡" tint="bg-sage/15" title="Seconds, not hours">Every format drafted in one pass — one upload becomes a full week of posts.</Feature>
        <Feature icon="🎯" tint="bg-clay/15" title="Native to each platform">YouTube, Instagram, Shorts, LinkedIn and X — each written the way that network reads.</Feature>
        <Feature icon="✍️" tint="bg-ink/10" title="Yours to edit">Edit, copy or regenerate any piece. Set your niche and tone once.</Feature>
      </section>

      <section id="pricing" className="mx-auto mt-24 max-w-6xl px-6">
        <h2 className="text-center text-3xl font-semibold tracking-tight md:text-4xl">Simple pricing</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {plans.map((p) => (
            <div key={p.name} className={`card-soft flex flex-col p-7 ${p.featured ? "outline-2 outline-sage" : ""}`}>
              <p className="text-sm font-semibold uppercase tracking-[0.15em] text-clay">{p.name}</p>
              <p className="mt-3 font-display text-4xl font-semibold">{p.price}<span className="text-base font-normal text-muted-foreground">/mo</span></p>
              <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
              <ul className="mt-5 flex-1 space-y-2 text-sm">
                {p.perks.map((k) => <li key={k} className="flex items-center gap-2"><Check className="size-4 text-sage" />{k}</li>)}
              </ul>
              <Button className="mt-6" variant={p.featured ? "sage" : "outline"} asChild><Link to={cta}>Get Started</Link></Button>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-6 py-12 text-center text-xs text-muted-foreground">
        Vireo — one video, every platform. Made for creators who'd rather make things than post them.
      </footer>
    </div>
  );
}

function Sample({ label, meta, children }: { label: string; meta: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-cream p-5 outline outline-1 outline-border">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-[0.15em] text-clay">{label}</span>
        <span className="text-[10px] text-muted-foreground">{meta}</span>
      </div>
      <div className="text-sm leading-relaxed text-foreground/80">{children}</div>
    </div>
  );
}

function Feature({ icon, tint, title, children }: { icon: string; tint: string; title: string; children: React.ReactNode }) {
  return (
    <div className="card-soft p-7">
      <div className={`mb-4 grid size-12 place-items-center rounded-2xl text-2xl ${tint}`}>{icon}</div>
      <h3 className="mb-2 text-xl font-semibold">{title}</h3>
      <p className="text-sm leading-relaxed text-muted-foreground">{children}</p>
    </div>
  );
}
