import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const kitSchema = z.object({
  youtube_titles: z.array(z.string()),
  youtube_description: z.string(),
  youtube_chapters: z.string(),
  instagram_hooks: z.array(z.string()),
  instagram_caption: z.string(),
  instagram_hashtags: z.string(),
  shorts_moments: z.array(z.object({ timestamp: z.string(), hook: z.string(), description: z.string() })),
  linkedin_post: z.string(),
  x_post: z.string(),
});

function systemPrompt(c: { niche: string; audience: string; language: string; tone: string } | null) {
  return `You are an expert social media strategist for video creators. Write in ${c?.language || "English"} with a ${c?.tone || "friendly"} tone.${c?.niche ? ` Creator niche: ${c.niche}.` : ""}${c?.audience ? ` Audience: ${c.audience}.` : ""} Be specific to the video, never generic. Do not invent facts beyond what the video information implies.`;
}

function videoInfo(p: { title: string; video_url: string | null; notes: string }) {
  return `Video title: ${p.title}\nVideo source: ${p.video_url?.startsWith("http") ? p.video_url : "uploaded file"}\nTranscript / description from creator:\n${p.notes || "(none provided — infer from title)"}`;
}

export const generateKit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { projectId: string }) => z.object({ projectId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { generateObject, friendlyAiError } = await import("./ai.server");
    // Atomic claim: only run once per project
    const { data: claimed } = await supabase
      .from("projects")
      .update({ status: "transcribing", error: null })
      .eq("id", data.projectId)
      .in("status", ["queued", "failed"])
      .select()
      .maybeSingle();
    if (!claimed) return { ok: true };
    const set = (status: string, error: string | null = null) =>
      supabase.from("projects").update({ status, error }).eq("id", data.projectId);

    try {
      const { data: creator } = await supabase.from("creator_profiles").select("*").eq("user_id", userId).maybeSingle();
      await set("analyzing");
      await new Promise((r) => setTimeout(r, 600));
      await set("generating");
      const kit = await generateObject(
        systemPrompt(creator),
        `${videoInfo(claimed)}\n\nGenerate: exactly 5 YouTube title ideas, a YouTube description, YouTube chapters (one per line, "0:00 Intro" format), exactly 5 Instagram reel hooks, an Instagram caption, Instagram hashtags (space separated, 15-20), exactly 3 best moments for Shorts/Reels with an estimated timestamp range, hook and short description, 1 LinkedIn post, 1 X post (under 280 chars).`,
        kitSchema,
      );
      const rows: { platform: string; content_type: string; content: string; position: number }[] = [];
      const add = (platform: string, content_type: string, content: string, position = 0) =>
        rows.push({ platform, content_type, content, position });
      kit.youtube_titles.slice(0, 5).forEach((t, i) => add("youtube", "title", t, i));
      add("youtube", "description", kit.youtube_description);
      add("youtube", "chapters", kit.youtube_chapters);
      kit.instagram_hooks.slice(0, 5).forEach((t, i) => add("instagram", "hook", t, i));
      add("instagram", "caption", kit.instagram_caption);
      add("instagram", "hashtags", kit.instagram_hashtags);
      kit.shorts_moments.slice(0, 3).forEach((m, i) =>
        add("shorts", "moment", `⏱ ${m.timestamp}\nHook: ${m.hook}\n${m.description}`, i),
      );
      add("social", "linkedin", kit.linkedin_post);
      add("social", "x", kit.x_post);
      await supabase.from("content_outputs").delete().eq("project_id", data.projectId);
      const { error } = await supabase
        .from("content_outputs")
        .insert(rows.map((r) => ({ ...r, project_id: data.projectId, user_id: userId })));
      if (error) throw error;
      await set("complete");
      return { ok: true };
    } catch (e) {
      console.error(e);
      const msg = (e as { statusCode?: number })?.statusCode ? friendlyAiError(e) : "Something went wrong while generating. Please try again.";
      await set("failed", msg);
      return { ok: false, error: msg };
    }
  });

const typeLabels: Record<string, string> = {
  title: "a YouTube title idea",
  description: "a YouTube video description",
  chapters: "YouTube chapters (one per line, '0:00 Title' format)",
  hook: "an Instagram reel hook (one line)",
  caption: "an Instagram caption",
  hashtags: "15-20 Instagram hashtags, space separated",
  moment: "a Shorts/Reels best moment in the format: '⏱ <timestamp range>\\nHook: <hook>\\n<short description>'",
  linkedin: "a LinkedIn post",
  x: "an X post under 280 characters",
};

export const regenerateOutput = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { outputId: string }) => z.object({ outputId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { generateText, friendlyAiError } = await import("./ai.server");
    const { data: out } = await supabase.from("content_outputs").select("*").eq("id", data.outputId).single();
    if (!out) return { ok: false as const, error: "Not found" };
    const { data: project } = await supabase.from("projects").select("*").eq("id", out.project_id).single();
    const { data: creator } = await supabase.from("creator_profiles").select("*").eq("user_id", userId).maybeSingle();
    try {
      const text = await generateText(
        systemPrompt(creator),
        `${videoInfo(project!)}\n\nWrite ${typeLabels[out.content_type] ?? "this content"}. Make it different from this previous version:\n"""${out.content}"""\nReturn only the content itself, no preamble or quotes.`,
      );
      await supabase.from("content_outputs").update({ content: text }).eq("id", out.id);
      return { ok: true as const, content: text };
    } catch (e) {
      console.error(e);
      return { ok: false as const, error: friendlyAiError(e) };
    }
  });
