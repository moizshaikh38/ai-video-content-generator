import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const projectsQuery = queryOptions({
  queryKey: ["projects"],
  queryFn: async () => {
    const { data, error } = await supabase.from("projects").select("*").order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },
});

export async function deleteProject(id: string, videoUrl: string | null) {
  if (videoUrl && !videoUrl.startsWith("http")) await supabase.storage.from("videos").remove([videoUrl]);
  const { error } = await supabase.from("projects").delete().eq("id", id);
  if (error) throw error;
}
