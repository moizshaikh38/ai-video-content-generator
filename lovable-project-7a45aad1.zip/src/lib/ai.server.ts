import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output } from "ai";
import type { z } from "zod";

const MODEL = "openai/gpt-6-astra";
const RUN_ID = "X-Lovable-AIG-Run-ID";

function provider() {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI is not configured.");
  let runId: string | undefined;
  return createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: async (input, init) => {
      const headers = new Headers(init?.headers);
      if (runId && !headers.has(RUN_ID)) headers.set(RUN_ID, runId);
      const res = await fetch(input, { ...init, headers });
      runId ??= res.headers.get(RUN_ID)?.trim() || undefined;
      return res;
    },
  });
}

const opts = {
  openai: {
    store: false,
    forceReasoning: true,
    reasoningEffort: "low",
    reasoningSummary: "auto",
    include: ["reasoning.encrypted_content"],
  },
} as const;

export function friendlyAiError(e: unknown): string {
  const status = (e as { statusCode?: number })?.statusCode;
  if (status === 402) return "AI credits are used up. Please add credits to keep generating.";
  if (status === 429) return "Too many requests right now. Please try again in a minute.";
  if (status === 403) return "AI access is currently blocked for this workspace.";
  return "AI generation failed. Please try again.";
}

export async function generateObject<T>(system: string, prompt: string, schema: z.ZodType<T>): Promise<T> {
  const result = streamText({
    model: provider().responses(MODEL),
    system,
    prompt,
    output: Output.object({ schema }),
    providerOptions: opts,
  });
  return (await result.output) as T;
}

export async function generateText(system: string, prompt: string): Promise<string> {
  const result = streamText({ model: provider().responses(MODEL), system, prompt, providerOptions: opts });
  return (await result.text).trim();
}
