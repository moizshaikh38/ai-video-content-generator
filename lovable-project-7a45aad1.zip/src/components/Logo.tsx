import { Link } from "@tanstack/react-router";

export function Logo({ to = "/" }: { to?: "/" | "/dashboard" }) {
  return (
    <Link to={to} className="flex items-center gap-3">
      <div className="grid size-10 place-items-center rounded-2xl bg-ink shadow-ink">
        <span className="text-sm font-bold text-cream">V</span>
      </div>
      <span className="font-display text-xl font-semibold tracking-tight">Vireo</span>
    </Link>
  );
}
