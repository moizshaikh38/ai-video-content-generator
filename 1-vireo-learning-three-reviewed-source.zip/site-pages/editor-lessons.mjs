// Three reviewed lessons. Source-only backup, not route integration.
export const editorLessons=[
  {
    "id": "word-timing",
    "category": "Captions",
    "title": "Adjust one word's start time",
    "time": "4 min",
    "summary": "Use the word timing controls and check the applied duration.",
    "steps": [
      {
        "title": "Inspect the word bounds",
        "text": "Open the word Timing controls. This example starts at 1.20 seconds and ends at 2.40 seconds, with a duration of 1200ms.",
        "media": "word-timing-before"
      },
      {
        "title": "Adjust the start carefully",
        "text": "The start changes to 1.25 seconds while the end remains at 2.40 seconds. The displayed duration changes to 1150ms. Listen around the boundary rather than guessing from the text alone.",
        "media": "word-timing-adjusted"
      },
      {
        "title": "Apply and review in context",
        "text": "Use Apply Word Timing, then inspect the transcript. The word badge shows 1.15s after applying.",
        "media": "word-timing-applied"
      },
      {
        "title": "Save and check again",
        "text": "Save and reopen your project to check that the timing remains. This example keeps the 1.15-second badge and corrected wording.",
        "media": "correction-reopened"
      }
    ],
    "task": "On a disposable copy, adjust one word slightly, listen with its neighbours and check the sentence before keeping the change.",
    "caveat": "A timing value can be saved without matching the speech perfectly. Listen to the word with its neighbours and check the exported subtitles before publishing."
  },
  {
    "id": "correct-captions",
    "category": "Captions",
    "title": "Correct a sentence and review the new timing",
    "time": "4 min",
    "summary": "Change the wording, reopen your project and check the timing effects.",
    "steps": [
      {
        "title": "Enter the intended wording",
        "text": "Open the sentence editor, compare with the source audio and enter the correction. Here the revised sentence is entered before Save.",
        "media": "correction-entered"
      },
      {
        "title": "Apply and inspect the sentence",
        "text": "After applying the edit, the changed wording appears in the transcript. Sentence rewriting redistributes word timings over the original cue, so inspect timing as well as spelling.",
        "media": "correction-applied"
      },
      {
        "title": "Reopen and check again",
        "text": "Save your project, reopen it and check the corrected wording. In this example the wording remains, along with a 1.15-second duration set in the word-timing lesson. Listen again to make sure the words still match the audio.",
        "media": "correction-reopened"
      }
    ],
    "task": "Correct one name against the source audio, reopen the sentence, then listen to the start and end of every affected word.",
    "caveat": "Rewriting can change word timings even when the sentence span stays the same. Listen to every affected word and review subtitle timing in the exported clip."
  },
  {
    "id": "caption-style",
    "category": "Captions",
    "title": "Change caption font, size and colours",
    "time": "5 min",
    "summary": "Find Typography & Layout and choose colours that keep your words readable.",
    "steps": [
      {
        "title": "Open Typography",
        "text": "Use the Typography tab for font, size and weight. Start with readable text before changing decorative effects.",
        "media": "caption-typography"
      },
      {
        "title": "Check the size change",
        "text": "The size changes from 70 to 95 in this example. The caption also moves upward, so check its position as well as its size.",
        "media": "caption-size-after"
      },
      {
        "title": "Choose the correct colour target",
        "text": "Open Effects. Text, Active, Stroke and Box affect different parts of the caption. This capture has Active selected with an orange swatch.",
        "media": "caption-colours"
      }
    ],
    "task": "Change one property at a time. Check whether readability improved before adjusting the next.",
    "caveat": "Resizing can change vertical placement too. Watch the whole sentence against the changing background, then check the downloaded file before publishing."
  }
];
export const captureMedia={
  "caption-typography": {
    "src": "/learning/editor/caption-typography.png",
    "width": 350,
    "height": 545,
    "alt": "Typography before resizing, with font size 70",
    "caption": "Find font, size, weight and line settings in Typography.",
    "annotated": true,
    "original": "04-typography.png",
    "crop": [
      70,
      135,
      420,
      680
    ]
  },
  "caption-size-after": {
    "src": "/learning/editor/caption-size-after.png",
    "width": 350,
    "height": 575,
    "alt": "Typography after resizing, with font size 95",
    "caption": "The size is now 95. Recheck the caption position after resizing.",
    "annotated": true,
    "original": "42-caption-resize-after.png",
    "crop": [
      70,
      135,
      420,
      710
    ]
  },
  "caption-colours": {
    "src": "/learning/editor/caption-colours.png",
    "width": 350,
    "height": 655,
    "alt": "Effects panel with Active colour selected",
    "caption": "Active is selected with an orange swatch. Text, Active, Stroke and Box are different targets.",
    "annotated": true,
    "original": "30-caption-active-color-effects.png",
    "crop": [
      70,
      135,
      420,
      790
    ]
  },
  "correction-entered": {
    "src": "/learning/editor/correction-entered.png",
    "width": 360,
    "height": 335,
    "alt": "Sentence rewrite entered before saving",
    "caption": "The revised wording is entered, ready to save.",
    "annotated": false,
    "original": "27-transcript-correction-entered.png",
    "crop": [
      1560,
      140,
      1920,
      475
    ]
  },
  "correction-applied": {
    "src": "/learning/editor/correction-applied.png",
    "width": 360,
    "height": 250,
    "alt": "Rewritten sentence in the transcript after applying the edit",
    "caption": "The changed wording appears in the transcript. Recheck timing after a sentence rewrite.",
    "annotated": false,
    "original": "28-transcript-correction-applied.png",
    "crop": [
      1560,
      140,
      1920,
      390
    ]
  },
  "correction-reopened": {
    "src": "/learning/editor/correction-reopened.png",
    "width": 360,
    "height": 250,
    "alt": "Corrected text and adjusted duration after reopening",
    "caption": "The corrected wording and 1.15-second duration remain after reopening.",
    "annotated": false,
    "original": "31-timing-correction-save-reopened.png",
    "crop": [
      1560,
      140,
      1920,
      390
    ]
  },
  "word-timing-before": {
    "src": "/learning/editor/word-timing-before.png",
    "width": 345,
    "height": 220,
    "alt": "Word Timing controls with start 1.20 and end 2.40 seconds",
    "caption": "Before adjustment: start 1.20s, end 2.40s, duration 1200ms.",
    "annotated": true,
    "original": "29-word-timing-controls-5ec3f3eb.png",
    "crop": [
      1515,
      25,
      1860,
      245
    ]
  },
  "word-timing-adjusted": {
    "src": "/learning/editor/word-timing-adjusted.png",
    "width": 345,
    "height": 220,
    "alt": "Word Timing start adjusted to 1.25 seconds",
    "caption": "Start is now 1.25s and end remains 2.40s. The displayed duration is 1150ms.",
    "annotated": true,
    "original": "39-word-timing-start-adjusted-1742539d.png",
    "crop": [
      1515,
      25,
      1860,
      245
    ]
  },
  "word-timing-applied": {
    "src": "/learning/editor/word-timing-applied.png",
    "width": 360,
    "height": 250,
    "alt": "Transcript word showing the applied 1.15-second duration",
    "caption": "After Apply Word Timing, the badge shows 1.15s.",
    "annotated": false,
    "original": "40-word-timing-applied-d1daae3f.png",
    "crop": [
      1560,
      140,
      1920,
      390
    ]
  }
};
