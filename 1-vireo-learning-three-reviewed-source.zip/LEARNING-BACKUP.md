# Reviewed Learning source backup

This backup contains only the three Learning pages shown in the November 17 review:

- Adjust one word's start time
- Correct a sentence and review the new timing
- Change caption font, size and colours

It includes their nine required native-pixel screenshot crops, a crop manifest, shared lesson rendering, styles and full-size image-dialog behaviour. The wording is consumer-facing; capture and verification details are recorded here instead of repeated throughout the lessons.

## Backup, not publication

These are source files only. No routes, library entries, sitemap entries, build wiring, deployment configuration or runtime editor files are changed. The three pages are not made routable by this commit. Other Learning pages and unrelated public-page work are intentionally excluded.

## Evidence notes

The screenshots use a permissioned public demonstration video credited in each lesson. Caption wording is illustrative, not its transcription. Cursor/click markers are added guidance and disclosed in the figures.

The sentence correction changes 'clear' to 'vivid'. Rewriting redistributes word timings over the original sentence cue, so learners must review timing after the correction. A refreshed reopened-project capture retains both the corrected wording and a later 1.15-second word duration. It is not the older 1.2-second reload capture, and its toolbar Save label is not presented as clean Saved-status proof.

The timing captures show the word start changing from 1.20 to 1.25 seconds while the end stays at 2.40 seconds. Apply produces a 1.15-second badge. They show the corrected local timing UI and reopened-project state, not exported timing accuracy.

The typography example compares size 70 and 95. The actual handle resize also moves the caption upward. It does not preserve the vertical anchor. The earlier size-70 Typography screenshot is explicitly a separate control view, not a continuous inspector sequence. Effects shows Active selected with an orange swatch. No completed exported styling or audio quality is claimed.

## Validation

These three pages were included in the sixteen-page local review run: 150 passing checks at widths 320, 390 and 1440 covering image loading, horizontal overflow, dialogs, Escape, focus return and movement-demo playback. The three updated phone pages were inspected after the consumer-copy revision. No new capture, product edit, analysis job or render was required for this backup.
